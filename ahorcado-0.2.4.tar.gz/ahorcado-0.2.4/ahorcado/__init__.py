#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# name:         ahorcadoPy (Python 3.x).
# description:  Aplicación de escritorio que revive el clásico juego de lápiz y
#               papel 'El Ahorcado'.
# author:       Jesús Cuerda Villanueva, https://github.com/Webierta/ahorcadoPy
# version:      0.2.4 Diciembre 2018
#
#-------------------------------------------------------------------------

