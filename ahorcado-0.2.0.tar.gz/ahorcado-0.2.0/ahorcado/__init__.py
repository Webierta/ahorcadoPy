#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# name:         ahorcado.py / __init__.py (Python 3.x).
# description:  Aplicación de escritorio que revive el clásico juego de lápiz y
#               papel 'El Ahorcado'.
# author:       Jesús Cuerda Villanueva, https://github.com/Webierta/ahorcadoPy
# version:      0.1.3 Diciembre 2018
#
#-------------------------------------------------------------------------

